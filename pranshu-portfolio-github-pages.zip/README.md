# Pranshu Portfolio

Personal portfolio website for GitHub Pages.

## Files
- `index.html` — website structure
- `style.css` — design and responsive styling

## GitHub Pages
Create a repository named `pranshu29-prog.github.io`, upload these files, then enable GitHub Pages from Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
